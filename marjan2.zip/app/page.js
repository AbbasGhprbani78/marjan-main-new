// app/page.js
import { redirect } from "next/navigation";

export default function RootRedirect() {
  redirect("/fa");
}
