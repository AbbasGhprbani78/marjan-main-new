export const data = {
  gallery: [
    "/images/24.png",
    "/images/35.png",
    "/images/27.png",
    "/images/28.jpg",
    "/images/29.png",
    "/images/30.png",
    "/images/31.png",
  ],
  products: [
    { image: "/images/32.png", text: "custer", size: "60*120" },
    { image: "/images/33.jpg", text: "custer", size: "60*60" },
    { image: "/images/34.jpg", text: "custer", size: "60*120" },
  ],
};
