export const calculator = {
  usecase: [
    { image: "/images/usecase/pool.jpg", title: "استخر-حمام" },
    { image: "/images/usecase/Outdoor.png", title: "پارکینگ- محیط خارجی" },
    { image: "/images/usecase/decorative.jpg", title: "دکوراتیو" },
    { image: "/images/usecase/commercial.jpg", title: "تجاری و پرتردد" },
    { image: "/images/usecase/residential.png", title: "مسکونی" },
    { image: "/images/usecase/nama 2.jpg", title: "نما" },
  ],
};
