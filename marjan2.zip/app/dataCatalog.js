export const catalogs = [
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "اصول نصب و نگهداری",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "پروژه ها",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "صنعتی",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "بیمارستانی",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "تک محصول",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "جنرال",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "پارکینگی",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "دکوراتیو",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "استخری",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "اصول نصب و نگهداری",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "پروژه ها",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "صنعتی",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "بیمارستانی",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "چرا مرجان",
  },
  {
    coverSrc: "/images/43.png",
    pdfSrc: "/files/pdf.pdf",
    category: "چرا مرجان",
  },
];

export const categories = [
  "اصول نصب و نگهداری",
  "پروژه ها",
  "صنعتی",
  "بیمارستانی",
  "تک محصول",
  "جنرال",
  "پارکینگی",
  "دکوراتیو",
  "استخری",
  "چرا مرجان",
];
