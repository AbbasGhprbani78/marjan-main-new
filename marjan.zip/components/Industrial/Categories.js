"use client";
import React, { useState } from "react";
import Tab from "../module/Tab";
import Image from "next/image";
import { useTranslation } from "@/context/TranslationContext";
import { MoreButton } from "../moreButton";
import Link from "next/link";
import { useLocalizedLink } from "@/utils/helper";

export default function Categories({ data }) {
  const [selected, setSelected] = useState(data[0]?.value ?? "");
  const selectedCategory = data.find((cat) => cat.value === selected);
  const { t } = useTranslation();
  const { localizedHref } = useLocalizedLink();

  const baseUrl = "/products";
  const industrieValues = data.map((item) => item.value).join("|");
  const queryString = `?industrie=${encodeURIComponent(
    industrieValues
  )}&page=1`;
  const finalUrl = `${baseUrl}${queryString}`;

  return (
    <>
      <h2 className="font-[500] title text-center mb-[2rem]">
        {t("Categories")}
      </h2>
      <Tab
        itemsFilter={data.map(({ value, label }) => ({
          value,
          label: label,
        }))}
        selected={selected}
        setSelected={setSelected}
      />

      {selectedCategory && (
        <Link
          href={localizedHref(
            `/products?industrie=${encodeURIComponent(
              selectedCategory?.value
            )}&page=1`
          )}
        >
          <div className="relative w-full aspect-[3/1] min-h-[200px] overflow-hidden mt-[30px]">
            <Image
              src={`${process.env.NEXT_PUBLIC_API_URL}${selectedCategory.image}`}
              alt={selectedCategory.value}
              fill
              className="object-cover transform transition-transform duration-[2000ms] ease-in-out hover:scale-[1.15]"
              unoptimized={true}
              quality={100}
              priority
            />
          </div>
        </Link>
      )}

      <div className="mt-[1rem] flex justify-center">
        <MoreButton
          text={t("Products")}
          width={263}
          height={46}
          className="mx-auto my-[35px] "
          href={finalUrl}
        />
      </div>
    </>
  );
}
