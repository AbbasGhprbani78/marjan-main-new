import React from "react";
import MapWrapper from "@/components/module/MapWrapper";
import styles from "./contactus.module.css";
import ContactusItem from "@/components/ContactUs/ContactusItem";
import { fetchContactUs } from "@/services/contactus";
export default async function page({ params }) {
  const { locale } = params;
  // const contactusData = await fetchContactUs(locale);

  const translations = {
    fa: {
      provinceName: "اصفهان",
      offices: [
        {
          name: "دفتر مرکزی",
          phone: "03136248019",
          email: "info@marjantileco.com",
          address: "اصفهان، چهارباغ بالا، کوچه کاویان، پلاک 45",
        },
        {
          name: "کارخانه واحد 2",
          phone: "03142290470",
          email: "info@marjantileco.com",
          address:
            "اصفهان، کمربندی شمالی نجف آباد، شهرک صنعتی منتظریه (ویلا شهر)، شرکت کاشی مرجان",
        },
        {
          name: "کارخانه واحد 1",
          phone: "03142290477",
          email: "info@marjantileco.com",
          address:
            "اصفهان، کمربندی شمالی نجف آباد، شهرک صنعتی منتظریه (ویلا شهر)، شرکت کاشی مرجان",
        },
      ],
      title: "تماس با ما",
    },
    en: {
      provinceName: "Isfahan",
      offices: [
        {
          name: "Head Office",
          phone: "03136248019",
          email: "info@marjantileco.com",
          address: "Isfahan, Chaharbagh Bala, Kavian Alley, No. 45",
        },
        {
          name: "Factory Unit 2",
          phone: "03142290470",
          email: "info@marjantileco.com",
          address:
            "Isfahan, Najafabad Northern Beltway, Montazeriyeh Industrial Town (Villa Shahr), Marjan Tile Company",
        },
        {
          name: "Factory Unit 1",
          phone: "03142290477",
          email: "info@marjantileco.com",
          address:
            "Isfahan, Najafabad Northern Beltway, Montazeriyeh Industrial Town (Villa Shahr), Marjan Tile Company",
        },
      ],
      title: "Contact Us",
    },
    ar: {
      provinceName: "أصفهان",
      offices: [
        {
          name: "المكتب الرئيسي",
          phone: "03136248019",
          email: "info@marjantileco.com",
          address: "أصفهان، جاده جهاباغ بالا، زقاق كاويان، رقم 45",
        },
        {
          name: "المصنع الوحدة 2",
          phone: "03142290470",
          email: "info@marjantileco.com",
          address:
            "أصفهان، الطريق الدائري الشمالي لنجف آباد، المنطقة الصناعية المنتظرية (فيلا شهر)، شركة مرجان للسيراميك",
        },
        {
          name: "المصنع الوحدة 1",
          phone: "03142290477",
          email: "info@marjantileco.com",
          address:
            "أصفهان، الطريق الدائري الشمالي لنجف آباد، المنطقة الصناعية المنتظرية (فيلا شهر)، شركة مرجان للسيراميك",
        },
      ],
      title: "اتصل بنا",
    },
    ru: {
      provinceName: "Исфахан",
      offices: [
        {
          name: "Главный офис",
          phone: "03136248019",
          email: "info@marjantileco.com",
          address: "Исфахан, Чахарбаг Бала, переулок Кавиан, дом 45",
        },
        {
          name: "Завод №2",
          phone: "03142290470",
          email: "info@marjantileco.com",
          address:
            "Исфахан, северная объездная Наджафабада, промышленная зона Монтазерие (Вила Шахр), компания Marjan Tile",
        },
        {
          name: "Завод №1",
          phone: "03142290477",
          email: "info@marjantileco.com",
          address:
            "Исфахан, северная объездная Наджафабада, промышленная зона Монтазерие (Вила Шахр), компания Marjan Tile",
        },
      ],
      title: "Свяжитесь с нами",
    },
  };

  const t = translations[locale] || translations.fa;

  const province = {
    name: t.provinceName,
    cities: t.offices.map((city, i) => ({
      ...city,
      x: [32.626021, 32.682744, 32.681213][i],
      y: [51.66114, 51.420689, 51.412748][i],
      link: `https://www.google.com/maps?q=${
        [32.626021, 32.682744, 32.681213][i]
      },${[51.66114, 51.420689, 51.412748][i]}`,
    })),
  };
  return (
    <main className="wrapper">
      <h1 className="sr-only">تماس با ما</h1>

      <div className="flex flex-col lg:grid lg:grid-cols-12 gap-[2rem] px-20 md:px-40 lg:px-80  pt-[140px] lg:pt-[120px] pb-[3rem]">
        <aside className="lg:col-span-4 xl:col-span-3 flex flex-col ">
          <section
            className={`block lg:hidden lg:col-span-8 xl:col-span-9 lg:h-full inset-0 z-0  mb-[1rem] ${styles.mapContainer}`}
            aria-label="نقشه دفاتر ما"
          >
            <MapWrapper province={province} />
          </section>
          <div
            className={`overflow-y-auto flex-1 ${styles.wrapperRepresentation}`}
            aria-label="لیست دفاتر"
          >
            {province?.cities?.map((info, i) => (
              <ContactusItem key={i} info={info} />
            ))}
          </div>
        </aside>
        <section
          className={`hidden lg:block lg:col-span-8 xl:col-span-9 lg:h-full inset-0 z-0  ${styles.mapContainer}`}
          aria-label="نقشه دفاتر ما"
        >
          <MapWrapper province={province} />
        </section>
      </div>
    </main>
  );
}
