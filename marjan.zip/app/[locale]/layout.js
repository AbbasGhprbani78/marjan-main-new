import "../globals.css";
import Footer from "@/app/components/Footer";
import { NavBar } from "@/app/components/navBar";
import { ToggleProvider } from "../context/context";
import ChatBot from "../components/module/ChatBot/ChatBot";
import ImageLoadingWrapper from "../components/ImageLoadingWrapper";
import { fetchHeaderFilter } from "@/services/header";

export const metadata = {
  title: "Marjan",
  // description: "Marjan Website",
  // icons: {
  //   icon: "/images/logo1.png",
  // },
};

export default async function RootLayout({ children, params }) {
  const { locale } = await params;

  const dir = locale === "fa" ? "rtl" : "ltr";
  const dataHeader = await fetchHeaderFilter(locale);

  return (
    <html lang={locale} dir={dir}>
      <ToggleProvider>
        <body className={locale === "fa" ? "font-fa" : "font-en"}>
          <ImageLoadingWrapper>
            <div className="page-container">
              <NavBar dataHeader={dataHeader} />
              <main className="content">{children}</main>
              <Footer />
            </div>
            <ChatBot />
          </ImageLoadingWrapper>
        </body>
      </ToggleProvider>
    </html>
  );
}
