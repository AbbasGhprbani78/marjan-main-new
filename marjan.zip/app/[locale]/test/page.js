"use client";
import React, { useEffect } from "react";

export default function Page() {
  useEffect(() => {
    const script = document.createElement("script");
    script.src =
      "https://www.aparat.com/embed/i19w4q4?data[rnddiv]=74226684546&data[responsive]=yes";
    script.type = "text/javascript";
    document.getElementById("aparat-player")?.appendChild(script);
  }, []);

  return (
    <div className="mt-[400px] w-[500px] h-[400px ]">
      <div id="aparat-player" className="w-full h-full"></div>
    </div>
  );
}
